// src/components/InventoryList.jsx
import React from 'react';


function InventoryList() {
    return(
        <>
            {/* Inventory list */}
        </>
    );
}

export default InventoryList;
